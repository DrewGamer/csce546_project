Parse.Cloud.afterSave("Attending", function(request) {
    // var dirtyKeys = request.object.dirtyKeys();
    // console.log(dirtyKeys.length +" keys dirty");

    Parse.Cloud.useMasterKey();

    console.log("Attending aftersave .... send notification to Creator of event");

    var user = request.user;
    var mevent = request.object.get("event");

    //get event from event id.
    var eventOb = new Parse.Object.extend("Event");
    var qEvent = new Parse.Query(eventOb);
    qEvent.include("creator"); //get the creator with this query
    qEvent.get(mevent.id, 
    {
        success: function(evnt) {
            //we cound the event, now get the user who created it.
            var creator = evnt.get("creator"); //since we "included" creator, it will be an object.
            if(creator)
            {
                var installationId = creator.get("installationId");
                if (installationId)
                {
                    var query = new Parse.Query(Parse.Installation);
                    query.containedIn("installationId", [installationId]);
                    
                    Parse.Push.send({
                        where: query,
                        data: {
                            alert: "New Attendee @" + evnt.get("title"),
                            badge: "Increment",
                            event:'attendee'
                        }
                    }, { useMasterKey: true },{
                        success: function() {
                            // Push was successful
                            console.log("push sent successfully!");
                        },
                        error: function(error) {
                            // Handle error
                            console.log("push error!");
                            console.log(error.message);
                        }
                    });
                }
                else
                    console.log("No InstallID i.e. creator does not have push enabled.");
            }
            else
                console.log("Event has no creator.... spookie");
      
        },
        error: function(error) {
            console.log("Error getting event...");
            console.log(error.message);
        }
    });

});